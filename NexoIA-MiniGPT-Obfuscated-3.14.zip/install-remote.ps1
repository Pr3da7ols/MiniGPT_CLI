$ErrorActionPreference = "Stop"
$PythonCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $PythonCmd) { throw "Instala CPython 3.14 y vuelve a ejecutar este archivo." }
$PyMinor = & $PythonCmd.Source -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
if ($PyMinor -ne "3.14") { throw "Esta distribución necesita CPython 3.14.x; detectado $PyMinor." }

$PackageDir = $PSScriptRoot
$VenvDir = if ($env:MINIGPT_REMOTE_VENV) { $env:MINIGPT_REMOTE_VENV } else { Join-Path $HOME ".venvs\minigpt-remote" }
& $PythonCmd.Source -m venv $VenvDir
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
& $VenvPython -m pip install --upgrade pip
& $VenvPython -m pip install $PackageDir
& $VenvPython -m mini_gpt.remote --cwd (Get-Location).Path
