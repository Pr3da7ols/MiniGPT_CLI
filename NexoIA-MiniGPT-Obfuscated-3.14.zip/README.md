# MiniGPT CLI

Tu asistente de IA para trabajar con proyectos desde la terminal de Termux. MiniGPT ejecuta las herramientas en el dispositivo y envía las conversaciones desde un servidor local hasta tu relay y tu IA:

```text
MiniGPT CLI → servidor local en Termux → tu relay → tu IA
```

El instalador configura el CLI. Para obtener respuestas de tu IA, también necesitas configurar la dirección y el token de tu relay. No publiques claves ni archivos `.env` en GitHub.

## Instalar en Termux

El instalador está preparado para el repositorio [Pr3da7ols/MiniGPT_CLI](https://github.com/Pr3da7ols/MiniGPT_CLI).

En Termux, ejecuta:

```bash
curl -fsSL https://raw.githubusercontent.com/Pr3da7ols/MiniGPT_CLI/main/install.sh | bash
```

Si Termux no reconoce `curl`, instálalo primero:

```bash
pkg update -y && pkg install -y curl
```

El instalador instala Git y Python, descarga el repositorio y crea el entorno de MiniGPT. No contiene tu token del relay ni tu clave de IA.

## Configurar tu IA

Después de instalar, abre el archivo de configuración:

```bash
nano ~/.mini_gpt/.env
```

Completa al menos estos valores con los datos de tu relay:

```dotenv
MINIGPT_RELAY_URL=https://TU_DOMINIO/relay
MINIGPT_RELAY_TOKEN=TU_TOKEN_DEL_RELAY
```

`MINIGPT_API_KEY` es la clave local que el CLI usa para hablar con el servidor de Termux; no es necesariamente la clave de tu proveedor de IA. Puedes dejarla vacía para que MiniGPT cree y comparta una clave local automáticamente. Guarda el archivo y cierra `nano` con `Ctrl+O`, `Enter` y `Ctrl+X`.

El relay debe estar activo y configurado para enviar las solicitudes a tu IA. `apiOpenAI.ts` no se instala desde este repositorio: debe estar desplegado donde corre tu relay. No pongas secretos dentro del README ni los subas a GitHub.

## Iniciar

En cada sesión de Termux, activa primero el entorno instalado:

```bash
source ~/.venvs/minigpt/bin/activate
```

En una sesión, deja el servidor local funcionando:

```bash
mini-gpt-server
```

En otra sesión, activa el entorno también y comprueba la conexión:

```bash
source ~/.venvs/minigpt/bin/activate
mini-gpt --doctor
mini-gpt
```

MiniGPT puede leer y modificar archivos y ejecutar comandos en el dispositivo. Para pedir aprobación antes de usar herramientas, inicia con:

```bash
source ~/.venvs/minigpt/bin/activate
mini-gpt --approval-mode ask
```

## Ejemplos

```bash
mini-gpt "explícame este proyecto"
mini-gpt -p "corrige el error" --cwd ~/mi-proyecto
cat error.log | mini-gpt -p "analiza este error"
mini-gpt --plan "propón una forma de probar este código"
mini-gpt --no-tools "explica qué significa este mensaje"
mini-gpt --help
```

En el modo interactivo puedes usar `/help`, `/tools`, `/plan`, `/save`, `/load`, `/compact`, `/undo` y `/exit`. Las sesiones se guardan en `~/.mini_gpt/sessions/`.

## Actualizar

Vuelve a ejecutar el mismo comando de instalación. Si el repositorio ya está clonado, el instalador lo actualiza y reinstala MiniGPT.

## Solución de problemas

- **No conecta con el relay:** revisa `MINIGPT_RELAY_URL`, `MINIGPT_RELAY_TOKEN` y que el relay esté en línea.
- **No aparece `mini-gpt`:** cierra y vuelve a abrir Termux, o activa el entorno con `source ~/.venvs/minigpt/bin/activate`.
- **Error al instalar desde GitHub:** comprueba que el repositorio sea público, que el nombre sea `MiniGPT_CLI` y que la rama sea `main`.
- **No compartas** `~/.mini_gpt/.env`, `~/.mini_gpt/api_key` ni tu token del relay.

## Conectar Nexo IA con un PC

El puente remoto permite que Nexo IA envíe tareas a MiniGPT en un PC de la misma red Wi-Fi. El PC ejecuta las herramientas y conserva los archivos en la carpeta elegida al iniciar el puente. El teléfono y el PC deben permanecer en la misma red local.

Antes del primer uso, configura en el PC `~/.mini_gpt/.env` con `MINIGPT_RELAY_URL` y `MINIGPT_RELAY_TOKEN`, igual que en la sección **Configurar tu IA**. El puente usa ese relay para las respuestas del modelo. `apiOpenAI.ts` en Termux es un cliente que hace llamadas salientes; por sí solo no publica un servidor al que el PC pueda conectarse cuando Termux está apagado. Para usarlo desde el PC, necesitas que el relay compatible con MiniGPT esté publicado en una dirección accesible desde ese PC.

En Windows PowerShell, desde la carpeta del proyecto que quieres abrir en Nexo IA, ejecuta:

```powershell
irm https://raw.githubusercontent.com/Pr3da7ols/MiniGPT_CLI/main/install-remote.ps1 | iex
```

En Linux o macOS, desde esa carpeta, ejecuta:

```bash
curl -fsSL https://raw.githubusercontent.com/Pr3da7ols/MiniGPT_CLI/main/install-remote.sh | bash
```

El instalador configura MiniGPT y arranca el puente. Deja esa terminal abierta y escribe en Nexo IA el código de 8 dígitos que muestra el PC. Si el firewall lo pregunta, permite conexiones entrantes en la red privada. El puente usa TCP `8765` y UDP `8766` en la red local.

El teléfono emparejado puede pedir a MiniGPT que lea, modifique y ejecute archivos del directorio indicado. El código cambia al reiniciar el puente. El control remoto va directamente por la Wi-Fi local; solo las solicitudes al modelo usan el relay configurado.

Los archivos del proyecto que MiniGPT cree o modifique aparecen en Nexo IA como tarjetas para abrir o descargar. Las imágenes guardadas con un nombre que empieza por `pantalla_` se muestran como capturas dentro del chat.

## Archivos principales

- `mini_gpt_cli.py`: CLI y agente que usa las herramientas locales.
- `mini_gpt.py`: lanzador de Python.
- `mini_gpt/`: servidor local compatible con OpenAI, configuración de relay y pruebas.
- `install.sh`: instalador para Termux.
- `install-remote.ps1` y `install-remote.sh`: instaladores del puente para PC.

Consulta [mini_gpt/README.md](mini_gpt/README.md) para más detalles sobre el servidor y el formato que debe aceptar el relay.
