#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON:-python3}"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    if command -v pkg >/dev/null 2>&1; then
        pkg install -y python
    else
        echo "No encuentro Python 3.14. Instálalo y vuelve a ejecutar este archivo." >&2
        exit 2
    fi
fi

if ! "$PYTHON_BIN" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 14) else 1)'; then
    echo "Esta distribución necesita CPython 3.14.x por los objetos marshal del ofuscador." >&2
    exit 2
fi

VENV_DIR="${MINIGPT_OBFUSCATED_VENV:-$HOME/.venvs/minigpt-obfuscated-3.14}"
"$PYTHON_BIN" -m venv "$VENV_DIR"
"$VENV_DIR/bin/python" -m pip install --upgrade pip
"$VENV_DIR/bin/python" -m pip install -e "${PACKAGE_DIR}[terminal]"

mkdir -p "$HOME/.mini_gpt"
if [ ! -f "$HOME/.mini_gpt/.env" ] && [ -f "$PACKAGE_DIR/mini_gpt/.env.example" ]; then
    cp "$PACKAGE_DIR/mini_gpt/.env.example" "$HOME/.mini_gpt/.env"
    chmod 600 "$HOME/.mini_gpt/.env"
fi

printf '\nMiniGPT ofuscado instalado.\n'
printf 'CLI: %s/bin/mini-gpt\n' "$VENV_DIR"
printf 'PC remoto: %s/bin/mini-gpt-remote\n' "$VENV_DIR"
printf 'Configura %s/.env con tu relay antes de usarlo.\n' "$HOME/.mini_gpt"
