#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON:-python3}"
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${MINIGPT_REMOTE_VENV:-$HOME/.venvs/minigpt-remote}"

if ! "$PYTHON_BIN" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 14) else 1)'; then
    echo "Esta distribución necesita CPython 3.14.x." >&2
    exit 2
fi

"$PYTHON_BIN" -m venv "$VENV_DIR"
"$VENV_DIR/bin/python" -m pip install --upgrade pip
"$VENV_DIR/bin/python" -m pip install "$PACKAGE_DIR"
exec "$VENV_DIR/bin/python" -m mini_gpt.remote --cwd "$PWD"
