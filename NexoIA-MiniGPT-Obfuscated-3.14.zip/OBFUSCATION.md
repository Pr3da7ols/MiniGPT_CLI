# Distribución ofuscada de Nexo IA

Los archivos Python fueron procesados con `obf.py` en 3 capas usando CPython 3.14.

**Requiere CPython 3.14.x.** El ofuscador serializa objetos `marshal`, cuyo formato de código no es portable entre versiones menores de Python.

Esto es ofuscación, no cifrado: dificulta la lectura casual, pero no impide recuperar el código. No es una forma segura de ocultar claves. No incluyas `.env`, tokens ni credenciales en GitHub.
