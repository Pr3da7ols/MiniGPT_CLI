# Informe final — Mini GPT API y tools complejas

## Resultado comprobado

- **187/187 tests offline aprobados** en la última ejecución, sin llamar al modelo.
  - 119 casos independientes del validador de schemas.
  - 55 casos independientes de parseo, selección, validación y serialización de tool calls.
  - 15 pruebas de regresión del servidor/API, incluidas pruebas de mensajes mayores a 20.000 caracteres en distintos roles y posiciones.
- **5/5 pruebas live básicas aprobadas** tras los cambios.
- **5/5 pruebas live avanzadas aprobadas** tras los cambios.

Las pruebas live usaron el mismo endpoint relay heredado del proyecto, a través del endpoint local `/v1`. No añadí otro servicio configurado ni cambié la URL relay. La última corrida hizo seis solicitudes por batería, pues el caso secuencial requiere dos turnos.

## Mejoras aplicadas

Se amplió el validador recursivo para cubrir tipos JSON, enum/const, required, propiedades adicionales y por patrón, `propertyNames`, dependencias de propiedades, límites de propiedades/arrays/strings/números, `uniqueItems`, `prefixItems`, `contains`, formatos comunes y combinadores `allOf`, `anyOf`, `oneOf` y `not`. Se compara la unicidad en forma eficiente, se tratan correctamente booleanos frente a números y los valores no finitos se rechazan. Se retiraron los límites y recortes específicos de 20.000 caracteres de los mensajes; sigue aplicándose un tope total de 1 MB al cuerpo HTTP.

Los patrones regulares proporcionados por schemas se limitan y se rechazan si parecen permitir retroceso catastrófico. Los resultados `role: "tool"` se etiquetan explícitamente como datos no confiables al convertir el historial.

Se mantienen las adaptaciones previas: llamadas singulares y paralelas, IDs individuales, `parallel_tool_calls: false`, SSE de múltiples llamadas, envelopes/fences `<escape>`/Markdown y reparación de llaves de cierre faltantes cuando el JSON aún puede recuperarse.

## Cobertura live final

La batería básica pasó tool call con cálculo y exclusión, JSON Schema ante prompt injection, ciclo de herramienta de dos turnos, `tool_choice: none` y streaming SSE.

La batería avanzada pasó selección correcta frente a una función distractora con argumentos anidados, llamadas paralelas a una herramienta con distintas ciudades, esas llamadas paralelas por SSE, lookup seguido por una cotización con cálculo y rechazo de una instrucción maliciosa dentro de un resultado de herramienta.

## Reproducir

Desde la carpeta del proyecto:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/live_stress.py
python tests/live_tools_stress.py
```

Las dos suites live consultan el relay y pueden consumir cuota; su resultado depende de la disponibilidad y variabilidad del servicio configurado. Los detalles están en `tests/live_stress_results.json` y `tests/live_tools_stress_results.json`.

## Límites

Un resultado de **197/197** al sumar 187 tests offline y 10 escenarios live significa que estas verificaciones concretas pasaron en esta ejecución; no demuestra compatibilidad universal ni inmunidad absoluta a prompt injection. Tools y JSON Schema se emulan mediante instrucciones más un adaptador porque el relay existente no ofrece estas capacidades como herramientas nativas documentadas. El validador implementa un subconjunto práctico, no todo JSON Schema (por ejemplo, no resuelve `$ref`). Mini GPT devuelve las tool calls al cliente HTTP y **no ejecuta** funciones proporcionadas por el cliente.
