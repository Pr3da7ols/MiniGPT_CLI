# Informe de pruebas complejas live — Mini GPT API

**Resultado final: 5/5 pruebas live aprobadas; 9/9 pruebas offline aprobadas.** Las pruebas live se enviaron por HTTP al servidor `/v1` local y llegaron al mismo `RELAY_URL` ya usado por la aplicación. Se usaron datos ficticios; no se invocaron servicios adicionales alternativos ni se ejecutó ninguna herramienta en el servidor.

## Resultados live

| Prueba | Resultado | Comprobación principal | Tiempo aprox. |
|---|---:|---|---:|
| Tool call forzado con impuesto, redondeo y exclusión de gasto personal | Aprobada | `submit_expense`; subtotal 293.75 USD, impuesto 24.23, total 317.98, exclusión 32.00 | 3.96 s |
| JSON Schema ante prompt injection en el documento | Aprobada | JSON válido; solo claves previstas; decisión `refund`; importe 89.99 USD | 3.11 s |
| Ciclo cliente HTTP completo de herramienta en dos turnos | Aprobada | llamada `convert_fahrenheit(137)`, resultado local 58.333... °C y respuesta final “58,3 °C” | 17.26 s |
| `tool_choice: "none"` con una herramienta disponible | Aprobada | respuesta textual, sin `tool_calls` | 2.49 s |
| Streaming SSE con forma de Chat Completions | Aprobada | chunk de contenido, chunk final y marcador `[DONE]` | 2.08 s |

Los tiempos varían entre solicitudes y ejecuciones; son observaciones de esta corrida, no una garantía de latencia.

## Hallazgo y corrección

El primer sondeo contra el relay heredado devolvió texto vacío. La causa fue una actualización del formato SSE del servicio configurado: ahora algunos snapshots llegan como `v.message`, mientras el parser solo leía `message` en la raíz. Se adaptó el parser para admitir la envoltura nueva y conservar la anterior; no se modificaron `MINIGPT_RELAY_URL`, el endpoint relay ni el cuerpo de solicitud existente.

La primera corrida compleja detectó además que el modelo repetía el wrapper `json_schema` y colocaba una instancia dentro de `schema`. Se reforzó la instrucción y se añadió normalización que solo desenvuelve ese patrón cuando la instancia interna satisface los campos/tipos básicos declarados. La repetición aprobó el validador de esta prueba.

## Alcance y límites

La prueba de JSON Schema verifica los tipos/enum/campos usados en este caso, no la cobertura completa del estándar JSON Schema. El endpoint heredado no ofrece garantía nativa de tools o schema strict: estas capacidades se emulan mediante instrucciones, interpretación y normalización. El resultado favorable de esta batería no demuestra que sea “la única API” que pasaría, ni garantiza consistencia en todos los prompts o modelos.

El ciclo de herramienta fue tipo cliente HTTP: Mini GPT devolvió `tool_calls`, el runner ejecutó localmente la conversión aritmética ficticia y envió el resultado en un mensaje `role: "tool"`. El servidor Mini GPT no ejecuta funciones suministradas por clientes.

## Reproducir

Desde la carpeta del proyecto:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/live_stress.py
```

Los tests unitarios sustituyen el modelo. El runner `live_stress.py` realiza seis solicitudes reales al relay configurado (cinco casos; el ciclo completo usa dos solicitudes) y puede consumir cuota o estar sujeto a cambios del servicio configurado.
