# Mini GPT 2.1: API local con relay en VPS

Servidor local compatible con la API de OpenAI (`/v1/chat/completions` y `/v1/models`). Reenvía cada conversación al relay de tu VPS, donde corre tu IA, y adapta la respuesta: historial, instrucciones de sistema, tools, JSON Schema y streaming.

```text
cliente (SDK de OpenAI, app, etc.) -> MiniGPT local :8080/v1 -> relay en tu VPS -> tu IA
```

Solo usa la biblioteca estándar de Python (3.9 o superior).

## Uso

1. Extrae el ZIP.
2. Copia `.env.example` como `.env` y rellena `MINIGPT_RELAY_URL` y `MINIGPT_RELAY_TOKEN`. Puedes dejar `MINIGPT_API_KEY` vacía: el servidor y el CLI crearán y compartirán la clave local guardada en `~/.mini_gpt/api_key`.
3. Ejecuta `mini-gpt-server` después de instalar el proyecto, o `python mini_gpt_server.py` desde la carpeta del proyecto.
4. Conecta tu cliente a `http://127.0.0.1:8080/v1` con `Authorization: Bearer <MINIGPT_API_KEY>`.

Las variables del entorno tienen prioridad sobre `.env`. Las opciones avanzadas están documentadas en `.env.example`.

## Contrato con el relay

MiniGPT envía `POST` a `MINIGPT_RELAY_URL` con la cabecera `X-MiniGPT-Relay-Token` y este cuerpo:

```json
{
  "message": "último mensaje",
  "history": [{"role": "user|assistant", "content": "..."}],
  "system_prompt": "instrucciones + tools + formato",
  "options": {"temperature": 0.2, "max_tokens": 500, "top_p": 1, "stop": ["..."], "seed": 1}
}
```

`options` solo se envía si el cliente indicó alguno de esos parámetros. Para que tengan efecto, el relay debe leerlos y pasárselos a tu IA.

La respuesta debe ser SSE (`data: {...}`), con fragmentos `{"v":[{"p":"/message/content/parts/0","o":"append","v":"texto"}]}` o snapshots `{"v":{"message":{...}}}`. MiniGPT procesa cada línea conforme llega, así que el streaming solo es real si el relay también envía fragmentos de forma incremental. Si el relay termina con `data: [DONE]`, activa `MINIGPT_REQUIRE_DONE=1` para que una respuesta cortada se detecte siempre.

## Comportamiento de errores

| Situación | Respuesta al cliente |
|---|---|
| El relay no responde | HTTP 502, `code: endpoint_error` |
| El relay excede `MINIGPT_RELAY_TIMEOUT` | HTTP 504, `code: endpoint_timeout` |
| El relay responde 429 | HTTP 429, `code: rate_limit_exceeded`, con su `Retry-After` y su mensaje |
| El relay responde 413, o un error con `code` `context_length_exceeded` / `message_length_exceeds_limit` | HTTP 400, `type: invalid_request_error`, `code: context_length_exceeded` (los harnesses compactan con este código) |
| El relay manda un evento `data: {"error": {...}}` dentro de un stream 200 | Se trata como error (mismo mapeo), nunca como respuesta exitosa |
| Cualquier otro error HTTP del relay | HTTP 502, `code: endpoint_error`, con el estado, el código y el mensaje del relay |
| La conexión se corta a mitad de la respuesta | HTTP 502, `code: incomplete_response` (ya no se entrega el texto parcial como si estuviera completo) |
| El modelo hace una tool call inválida, o responde en texto con `tool_choice` obligatorio | Se reintenta `MINIGPT_TOOL_RETRIES` veces indicándole el error; si sigue mal: HTTP 502, `code: invalid_tool_call` |

En modo streaming, las cabeceras SSE se envían con el primer fragmento: si el fallo ocurre **antes** de emitir texto, el cliente recibe el estado HTTP real de la tabla (y su SDK puede reintentar). Si ocurre **después**, llega como un evento `data: {"error": ...}` antes de `[DONE]`.

## Uso con agentes (harness)

- Hasta `MINIGPT_MAX_MESSAGES` mensajes (1000) y `MINIGPT_MAX_BODY_BYTES` (8 MB) por solicitud.
- Al relay se reenvían los últimos `MINIGPT_MAX_HISTORY` mensajes (40), opcionalmente limitados a `MINIGPT_MAX_HISTORY_CHARS`. La **tarea original** (primer mensaje del usuario) se conserva siempre, con una nota de cuántos pasos intermedios se omitieron.
- `GET /v1/models/{id}` devuelve la ficha del modelo (algunos clientes lo usan para validarlo).

## Notas

- En multi-turno el relay reenvía toda la conversación (los turnos anteriores como snapshots y el nuevo creciendo con parches). MiniGPT reconstruye **solo el último mensaje del asistente**, así que la respuesta no arrastra el turno previo ni pierde las primeras letras del nuevo.
- `stop` se **fuerza localmente** además de reenviarse al relay: la respuesta (y el `usage`) se cortan en la primera secuencia encontrada, incluso en streaming cuando la secuencia llega partida entre dos fragmentos. Así el parámetro funciona aunque el relay no lo respete.
- `max_tokens` (o `max_completion_tokens`) también se **fuerza localmente** (presupuesto ≈ 4 caracteres por token): si el relay no lo respeta, la respuesta se recorta igual —en streaming y sin streaming— y `finish_reason` pasa a `"length"`. No se aplica a tool calls ni a JSON estructurado para no romper el JSON.
- Si el relay no responde dentro de `MINIGPT_RELAY_TIMEOUT`, el cliente recibe **HTTP 504** con `code: endpoint_timeout` (antes caía como 502 genérico).
- Solo se genera **una** respuesta por solicitud: un `n` distinto de 1 se rechaza con HTTP 400 en vez de devolver una sola opción en silencio.
- `usage` **solo se reporta si el relay lo envía** en su stream (un evento con `"usage":{"prompt_tokens":N,"completion_tokens":M}`; también acepta `input_tokens`/`output_tokens`). Si no lo envía, `usage` es `null` (no disponible): nunca se estima como si fuera real. Con reintentos de tool calls se suma el uso de todos los intentos, y si alguno no lo trae el total es `null`.
- Tools y JSON Schema se emulan con instrucciones y validación local; el validador cubre un subconjunto práctico de JSON Schema (no resuelve `$ref`).
- MiniGPT nunca ejecuta las funciones del cliente: solo devuelve las `tool_calls`.

## Seguridad

- **No compartas `.env`.** Los `.cmd` ya no contienen secretos; el proyecto se puede compartir sin `.env`.
- Usa HTTPS entre tu equipo y la VPS (por ejemplo, un dominio con Caddy o nginx delante del relay) o un túnel SSH/WireGuard. Con `http://`, el token y los mensajes viajan sin cifrar; el servidor lo avisa al iniciar.
- En la VPS, limita con el firewall qué IPs pueden entrar al puerto del relay.

## Pruebas

```bash
python -m unittest discover -s tests -p 'test_*.py' -v   # offline, sin llamar al relay
python tests/live_stress.py                                # live, consume solicitudes al relay
python tests/live_tools_stress.py                          # live, tools avanzadas
```
